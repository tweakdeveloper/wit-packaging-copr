This directory is only for test purposes. 'test-libwbfs' should confirm
that libwbfs can be used independently of the WIT project.
